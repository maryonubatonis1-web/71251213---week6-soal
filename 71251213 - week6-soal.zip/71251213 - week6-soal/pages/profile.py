import streamlit as st
from user import user_data_by_username

# CEK APAKAH SUDAH LOGIN
if "logged_in" not in st.session_state or not st.session_state.logged_in:
    st.switch_page("app.py")
    
user = user_data_by_username()

# hint untuk mematikan text input ada di -> https://docs.streamlit.io/develop/api-reference/widgets/st.text_input
# BUAT 2 INPUT TEXT 1 Username 1 Password namun disable/matikan field Username dan yang password harus tipe password
username_lama = st.session_state.username
password_lama = user[username_lama]["password"]

st.text_input("Username", value=username_lama, disabled=True)
password_baru = st.text_input("Password Baru", value=password_lama, type="password")

# Silahkan kalau mau baca baca ini hehe ga wajib ya-> https://discuss.streamlit.io/t/buttons-alignment/51929
col1, col2 = st.columns([1,4])
with col1:
    # Buat tombol logout st.button("logout", type="primary") keluar ke app.py
    if st.button("Logout", type="primary"):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.session_state.role = ""
        st.switch_page("app.py")
with col2:
    if st.button("Ganti Data", type="secondary"):
        if password_baru == password_lama:
            st.error("Passwordnya gaboleh sama woiii.")
        else:
            user[username_lama]["password"] = password_baru
            st.success("Berhasil ni e.")
    # Ini untuk ubah password st.button("Ganti Data", type="secondary", width=400)
    # Kondisi -> Password baru dan lama ga boleh sama 
    # Jika sama -> st.error("ga boleh sama wok")
    # jika beda ubah melalui variabel 'user' lalu tampilkan st.success("Berhasil")
